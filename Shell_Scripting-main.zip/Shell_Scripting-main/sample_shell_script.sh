#!/bin/bash

#create a folder
mkdir uday

# create two files
cd uday
touch firstfile secondfile
