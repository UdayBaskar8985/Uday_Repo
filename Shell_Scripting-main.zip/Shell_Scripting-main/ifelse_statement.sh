#!/bin/bash

#This is a basic if else statement
a=4
b=10

if [$a > $b]
then 
	echo "a is greater than b"
else
	echo "b is greater than a"
fi
