#!/bin/bash
# Concatenate strings
first_name="John"
last_name="Doe"
full_name="$first_name $last_name"
echo "Full Name: $full_name"

# String length
echo "Length of first name: ${#first_name}"

