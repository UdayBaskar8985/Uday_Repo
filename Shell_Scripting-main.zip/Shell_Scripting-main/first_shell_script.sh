#!/bin/bash

echo "My Name is Uday. I am learning Shell Scripting. This is my first Shell Script"
