#!/bin/bash


#iterations -> for, while, until, select
#This is a for Loop Example

for i in {1.100}; do echo $1;done



